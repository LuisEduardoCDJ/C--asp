﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Tarea_4
{
    class CrearFac
    {
        public void Comprar() 
        {
            int a;

            List<string> Lista = new List<string>();
            Lista.Add("1. Pan       100$");
            Lista.Add("2. Huevo     150$");
            Lista.Add("3. Leche     200$");
            Lista.Add("4. Arroz     200$");
            Lista.Add("5. Aceite    150$");
            Lista.Add("6. Verduras  50$");
            Lista.Add("7. Vegetales 50$");
            Lista.Add("8. Frutas    50$");
            Lista.Add("9. Carne     300$");
            

            foreach (string alimentos in Lista) {Console.WriteLine(alimentos);}
            Console.WriteLine("[1. Canasta Completa] [2. Aliemtos solo]");
            a = int.Parse(Console.ReadLine());
            if (a == 1)
            {
                Console.Clear();
                foreach (string alimentos in Lista) { Console.WriteLine(alimentos); }
                int b = 1250;
                int c;
                Console.WriteLine($"Total: {b}");
                Console.WriteLine("Ingrese dinero para pagar:");
                c = int.Parse(Console.ReadLine());

                if (c >= b) { Console.WriteLine($"Has pagado exitosamente {b}"); Console.WriteLine("Le sobran " + (c - b)); }
                else { Console.Clear(); Console.WriteLine($"{c} no es suficiente para pagar {b}."); Comprar(); }
            }
            else if (a == 2) 
            {
                Console.Clear();
                foreach (string alimentos in Lista) 
                { 
                    Console.WriteLine(alimentos); 
                }

                int c;
                int p;
                Console.WriteLine("Que deseas comprar:");
                c = int.Parse(Console.ReadLine());

                switch (c) 
                {
                    case 1:
                        Console.WriteLine("Has comprado Pan");
                        break;
                    case 2:
                        Console.WriteLine("Has comprado Huevos");
                        break;
                    case 3:
                        Console.WriteLine("Has comprado Leche");
                        break;
                    case 4:
                        Console.WriteLine("Has comprado Arroz");
                        break;
                    case 5:
                        Console.WriteLine("Has comprado Aceite");
                        break;
                    case 6:
                        Console.WriteLine("Has comprado Verduras");
                        break;
                    case 7:
                        Console.WriteLine("Has comprado Vegetales");
                        break;
                    case 8:
                        Console.WriteLine("Has comprado Frutas");
                        break;
                    case 9:
                        Console.WriteLine("Has comprado Carne");
                        break;
                    default:
                        Console.WriteLine("Error");
                        Comprar();
                        break;
                }
            }
            else { Comprar(); }
        }
    }
}
