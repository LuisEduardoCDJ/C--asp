﻿using System;
using System.Collections.Generic;

namespace Tarea_4
{
    class Program 
    {
        static void Main(string[] args)
        {
            IApdater.Menu();
        }
    }
}
