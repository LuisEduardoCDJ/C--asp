﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Tarea_4
{
    class IntroFac
    {
        public void Introducir() 
        {
            int a;
            double r = 6000;
            List<string> Lista = new List<string>();
            Lista.Add(" Tenis     2000$");
            Lista.Add(" Camisa    1500$");
            Lista.Add(" Crocs     2000$");
            Lista.Add(" Poloche   500$");
           

            Console.WriteLine("[1. Añadir] [2. Salir]");
            a = int.Parse(Console.ReadLine());
            
            if (a == 1) 
            {
                Console.Clear();
                int q;
                string productos;
                int p;
                double x = 0.18; /*El impuesto que pondre sera 15% segun mi invetigacion los % pasan a tener un 0 alante por ejemplo: 50% 0.50, 
                                  https://www.ennaranja.com/para-ahorradores/rebajas-estos-son-todos-los-trucos-matematicos-que-necesitas-saber-para-que-no-te-enganen/
                                 partiendo de aqui deduje eso.*/
                double x1 = 0.10;
                double p1;
                int po;

                Console.WriteLine("Que es su agrego?\n[1. Ropa. ][2. Tecnologia.]");
                po = int.Parse(Console.ReadLine());
                Console.WriteLine("Digite su producto:\nNota: Precione 4 veces [Space] depues introducir el producto");
                productos = Console.ReadLine();
             
                if (po == 1) 
                {
                    Console.WriteLine("Cual es el precio?");
                    p = int.Parse(Console.ReadLine());
                    p1 = p * x;
                    Lista.Add(productos + (p + p1) +"$");
                    Console.Clear();
                    foreach (string alimentos in Lista) { Console.WriteLine(alimentos); }
                    Console.WriteLine($"Factura del nuevo producto\nProducto: {productos + p}\nITBS: {p1}\nSubtotal{p + p1}");
                }
                else
                {
                    Console.WriteLine("Cual es el precio?");
                    p = int.Parse(Console.ReadLine());
                    p1 = p * x1;
                    Lista.Add(productos + (p + p1) + "$");
                    Console.Clear();

                    foreach (string alimentos in Lista) { Console.WriteLine(alimentos); }
                    Console.WriteLine($"Factura del nuevo producto\nProducto:  {productos + p}\nITBS:   {p1}\nSubtotal:  {p+p1}");
                }

                Console.WriteLine("[1. Volver añadir]  [2. salir]");
                q = int.Parse(Console.ReadLine());
                if (q == 1) { Introducir(); }
                else { Console.WriteLine("Has salido."); Console.ReadLine(); }
            }
            else { Console.Clear(); Console.WriteLine("Error."); Console.ReadLine(); }
        }
    }
}
