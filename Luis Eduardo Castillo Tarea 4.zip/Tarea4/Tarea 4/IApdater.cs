﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Tarea_4
{
    public interface IApdater
    {
        public static void Menu() 
        {
            int o;
            Console.WriteLine("***************************************");
            Console.WriteLine("** Bienvenido al colmado la solicion **");
            Console.WriteLine("***************************************");
            Console.WriteLine("Que dea realizar");
            Console.WriteLine("[1. Comprar.]    [2. Añadir Producto.]");

            o = int.Parse(Console.ReadLine());
            if (o == 1) { CrearFac p = new CrearFac(); p.Comprar(); }
            else if (o == 2) { IntroFac p = new IntroFac(); p.Introducir(); }
            else {Menu(); }
        }
    }
}
